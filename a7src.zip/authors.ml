(* TODO: set the value below *)
let hours_worked = [9; 11; 10; 9]
